	// START: LIBCHAT SPRINGSHARE
	setTimeout(function(){
		var libchatHash = 'a37166615792477be4e77ecc2adcd300';
		var d = document.createElement('div');
		d.id = 'libchat_' + libchatHash;
		d.className = 'lib-chat';
		document.body.appendChild(d);
		
		var s = document.createElement('script');
		s.id = 'libchat-script';
		s.type = 'text/javascript';
		s.src = 'https://v2.libanswers.com/load_chat.php?hash=' + libchatHash;
		document.body.appendChild(s);
	}, 2000); 
	// END: SpringShare LibChat 